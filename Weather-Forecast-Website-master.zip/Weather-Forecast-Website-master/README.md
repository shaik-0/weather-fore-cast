# Weather-Forecast-Website
A Weather-Forecast Webiste using Flask and jinja logic.
It will tell us the current weather.
